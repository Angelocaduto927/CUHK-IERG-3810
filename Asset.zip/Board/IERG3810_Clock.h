#ifndef __IERG3810_CLOCK_H
#define __IERG3810_CLOCK_H
#include "stm32f10x.h"

// put procedure header here

void clocktree_init(void);
void delay(u32);

#endif


