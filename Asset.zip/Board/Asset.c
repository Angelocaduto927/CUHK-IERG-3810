#include "stm32f10x.h"
#include "LCD_SETUP.h"
#include "IERG3810_Clock.h"
#include "FONT.h"


const u8 character1[25][20]=  //red 1 black 2  dark gray 3  gray 4 light gray 5
{
	{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
	{1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0},
	{1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
	{0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0},
	{0,0,0,0,0,2,2,4,4,2,2,2,2,2,2,4,0,0,0,0},
	{0,0,0,0,2,4,4,2,2,4,4,4,4,4,2,2,4,0,0,0},
	{0,0,2,2,4,4,2,2,4,4,4,4,4,4,4,4,2,2,0,0},
	{0,0,2,4,4,2,2,4,4,4,4,2,2,4,4,4,4,2,4,0},
	{0,2,2,2,2,4,4,4,2,4,4,2,2,4,4,2,4,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,2,2,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,2,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,2,4,2,2,4,4,2,4,4,2,2,4,4,2,4,2,2,0},
	{0,0,2,2,2,2,2,4,4,4,4,4,4,4,4,4,2,2,0,0},
	{0,0,3,3,3,4,2,2,2,2,2,2,2,2,2,2,3,3,3,0},
	{0,3,3,3,3,3,5,5,5,5,5,6,5,5,5,3,3,3,3,3},
	{0,3,3,3,3,3,2,2,2,5,5,5,5,2,2,2,3,3,3,3},
	{0,0,0,0,2,2,5,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,5,5,5,5,5,5,5,5,5,2,0,0,0,0},
	{0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,0,3,3,3,0,0,0,0,3,3,3,0,0,0,0,0},
	{0,0,0,0,0,0,3,3,0,0,0,0,0,3,3,0,0,0,0,0},
};
const u8 character2[25][20]=  //red 1 black 2  dark gray 3  gray 4 light gray 5
{
	{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
	{1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0},
	{1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
	{0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0},
	{0,0,0,0,0,2,2,2,4,4,4,4,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,4,4,4,4,4,4,4,4,2,2,2,0,0,0},
	{0,0,2,2,2,4,4,4,4,4,4,4,4,4,4,2,2,2,0,0},
	{0,0,2,2,2,4,4,4,4,4,4,4,4,4,4,4,4,2,2,0},
	{0,2,2,2,4,4,4,4,4,4,4,4,4,4,4,4,4,4,2,2},
	{0,2,2,4,4,4,4,2,2,2,2,2,2,2,2,2,4,4,2,2},
	{0,2,2,4,4,4,2,2,2,2,2,2,2,2,2,2,2,4,2,2},
	{0,2,2,4,4,4,4,2,2,2,2,2,2,2,2,2,4,4,2,2},
	{0,2,2,4,4,4,4,4,4,4,4,2,2,2,4,4,4,4,2,2},
	{0,2,2,4,4,4,4,4,4,4,4,2,2,2,4,4,4,4,2,2},
	{0,0,2,2,2,2,4,4,4,4,4,2,2,2,4,4,4,2,2,0},
	{0,0,2,2,2,2,2,4,4,4,4,2,2,2,4,4,2,2,0,0},
	{0,0,3,3,3,4,2,2,2,2,2,2,2,2,2,2,3,3,3,0},
	{0,3,3,3,3,3,5,5,5,5,5,6,5,5,5,3,3,3,3,3},
	{0,3,3,3,3,3,2,2,2,5,5,5,5,2,2,2,3,3,3,3},
	{0,0,0,0,2,2,5,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,5,5,5,5,5,5,5,5,5,2,0,0,0,0},
	{0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,0,3,3,3,0,0,0,0,3,3,3,0,0,0,0,0},
	{0,0,0,0,0,0,3,3,0,0,0,0,0,3,3,0,0,0,0,0},
};

void drawDotForChar(u8 color, u16 x, u16 y)   
{
	if(color == 1) lcd_drawDot(x, y, c_RED);
	if(color == 2) lcd_drawDot(x, y, c_black);
	if(color == 3) lcd_drawDot(x, y, c_DARK_GRAY);
	if(color == 4) lcd_drawDot(x, y, c_GRAY);
	if(color == 5) lcd_drawDot(x, y, c_LIGHT_GRAY);
	if(color == 6) lcd_drawDot(x, y, c_GREEN);
}

void lcd_showChar(u16 x, u16 y, u8 ascii, u16 color)
{
	u8 i, b, temp1, temp2;
	u16 tempX, tempY;
	if (ascii<32 || ascii >127) return;
	ascii -= 32;
	tempX = x;
	for (i=0; i<16; i=i+2)
	{
		temp1 = asc2_1608[ascii][i];
		temp2 = asc2_1608[ascii][i+1];
		tempY = y;
		for (b=0;b<9;b++)
		{
			if(temp1%2 == 1) lcd_drawDot(tempY+8, tempX, color);
			if(temp2%2 == 1) lcd_drawDot(tempY, tempX, color);
			temp1 = temp1 >>1;
			temp2 = temp2 >>1;
			tempY++;
		}
		tempX--;
	}
}







/////////////////////////////////////////Only use below function////////////////////////////////////////
void Draw_Character(u16 x, u16 y, u8 which, s8 d) // d directtion can be 1 (right) or -1 (left)
{	
	u8 tempcolor,i,j;
	u16 coordx,coordy;
	if(which == 1)
	{
		for(i=0;i<25;i++)
		{
			for(j=0;j<20;j++)
			{
				tempcolor = character1[i][j];
				coordy = y + 18 - i; 
				coordx = x - (11 - j)*d;// change direction
				drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	else
	{
		for(i=0;i<25;i++)
		{
			for(j=0;j<20;j++)
			{
				tempcolor = character2[i][j];
				coordy = y + 18 - i; 
				coordx = x - (11 - j)*d;// change direction
				drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
}
void Draw_ARENA(void)
{
	lcd_fillRectangle(c_black,0,10,0,320); //level 1
	
	lcd_fillRectangle(c_black,60,10,0,120); //level 2
	lcd_fillRectangle(c_black,60,10,200,120);
	
	lcd_fillRectangle(c_black,120,10,80,160); //level 3
	
}

void Draw_HPValue(u8 HP_value1, u8 HP_value2)
{
	lcd_fillRectangle(c_black,223,14,213,104);
	lcd_fillRectangle(c_black,223,14,3,104);
	lcd_fillRectangle(c_GREEN,225,10,315-HP_value1,HP_value1);
	lcd_fillRectangle(c_GREEN,225,10,5,HP_value2);
}

void Draw_Countdown(u8 min, u8 sec)
{
	u8 sec1,sec2;
	sec2 = sec%10;
	sec1 = sec/10; 
	lcd_showChar(176, 224, 0x30+min, c_black);
	lcd_showChar(168, 224, 0x3A, c_black);
	lcd_showChar(160, 224, 0x30+sec1, c_black);
	lcd_showChar(152, 224, 0x30+sec2, c_black);
}

void Draw_HealPack()
{

}

///remember to replace delay with systick
/*int main(void)
{
	delay(1000000);
	lcd_init();
	delay(1000000);
	lcd_fillRectangle(c_SADDLE_BROWN,0,240,0,320);
	Draw_ARENA();
	Draw_Character(11,16,1,1);
	Draw_Character(308,16,2,-1);
	Draw_HPValue(39,88);

  Draw_Countdown(3,12);
	while(1);

}*/

