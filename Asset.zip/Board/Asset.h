#ifndef __IERG3810_LCD_Asset_H
#define __IERG3810_LCD_Asset_H
#include "stm32f10x.h"




void Draw_Countdown(u8 min, u8 sec);
void Draw_HPValue(u8 HP_value1, u8 HP_value2);
void Draw_ARENA(void);
void Draw_Character(u16 x, u16 y, u8 which, s8 d); // d directtion can be 1 (right) or -1 (left)

#endif
