#pragma once
#include "stm32f10x.h"

void clocktree_init(void);
