#pragma once
#include "stm32f10x.h"


#define TX_BUFFER_SIZE 16
volatile uint8_t tx_buf[TX_BUFFER_SIZE];
volatile uint8_t tx_head = 0;
volatile uint8_t tx_tail = 0;

#define RX_BUFFER_SIZE 16
volatile uint8_t rx_buf[RX_BUFFER_SIZE];
volatile uint8_t rx_head = 0;
volatile uint8_t rx_tail = 0;

#define RX_AVAILABLE (rx_head != rx_tail)
#define TX_EMPTY (tx_head == tx_tail)



void usart2exti_init(u32 pclkl, u32 baud);

//Below are codes for receiving, adjust if needed
/*
if(RX_AVAILABLE)
    {
				u8 instruction;
        u8 val = rx_buf[rx_tail];
        rx_tail = (rx_tail + 1) % RX_BUFFER_SIZE;

        if(val ==  0x32  ) instruction=1;
        if(val ==  0x38  ) instruction=2;
				if(val ==  0x34  ) instruction=3;
        if(val ==  0x36  ) instruction=4;
				if(val ==  0x39  ) instruction=5;
    }
		*/
