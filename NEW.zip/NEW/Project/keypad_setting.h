#pragma once
#include <stm32f10x.h>

int READ_KEYPAD(void);
