#pragma once
#include "stm32f10x.h"

int RANDOM_RANGE(int min, int max);
int RANDOM_LOOT(void);
