#pragma once
#include "stm32f10x.h"

void delay(u32 count);
