#include "IERG3810_Delay.h"

void delay(u32 count)
{
    u32 i;
    for (i = 0; i < count; i++)
        ;
}
