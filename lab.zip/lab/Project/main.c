#include <stm32f10x.h>
#include "stm32f10x_it.h"
#include "IERG3810_KEY.h"
#include "IERG3810_LED.h"
#include "IERG3810_Buzzer.h"
#include "IERG3810_Clock.h"
#include "IERG3810_USART.h"
#include "IERG3810_Delay.h"
#include "IERG3810_EXTI.h"
#include "IERG3810_Keypad.h"
#include "IERG3810_Timer.h"
#include "character_setting.h"
#include "weapon_setting.h"
#include "HP_setting.h"
#include "bullet_setting.h"
#include "randomness.h"
#include "draw.h"
#include "LCD_SETUP.h"

extern u32 TASKS[10];
CHARACTER character1;
CHARACTER character2;
volatile int time = 1801;
int main()
{
	// INIT_FUNC();
	character1 = CREATE_CHARACTER_1();
	character2 = CREATE_CHARACTER_2();
	clocktree_init();
	systick_init_100ms();
	IERG3810_LED_Init();
	nvic_setPriorityGroup(5);
	ps2key_extiInit();
	lcd_init();
	delay(1000000);
	TASKS[0] = 3;
	TASKS[1] = 301;
	TASKS[2] = 101;
	TASKS[5] = 1;
	lcd_fillRectangle(c_white, 0,240, 0, 320);
	delay(100000);
	DRAW_ARENA();
	DRAW_HP_VALUE(character1);
	DRAW_HP_VALUE(character2);
	weapon_list_init(&weaponlist);
	HP_list_init(&hplist);
	Bullet_list_init(&bulletlist1);
	Bullet_list_init(&bulletlist2);
	tim2_init(799, 8999);
	while(1)
	{
		if(TASKS[0] == 1)
		{	
			TASKS[0] = 3;
			int instruction = 0;
			ps2count = 0;
			ones = 0;
			full_data = 0;
			EXTI->IMR |= (1<<11);
			TASKS[4] = 3;
			while(TASKS[4] > 1 && ps2count < 11){}
			if(ps2count != 11){instruction = 0;}
			else{
				EXTI->IMR &= ~(1<<11);
				if (parity_check(full_data) == 1)
				{
					if (kp2_pressed)
					{
						//return 1;
						instruction = 1;
					}
					if (kp8_pressed)
					{
						//return 2;
						instruction = 2;
					}
					if (kp4_pressed)
					{
						//return 3;
						instruction = 3;
					}
					if (kp6_pressed)
					{
						//return 4;
						instruction = 4;
					}
					if (kp9_pressed)
					{
						//return 5;
						instruction = 5;
					}
				}	
				else{}
				//ps2count = 0;
				//ones = 0;
				//last_two_data = last_one_data;
				//last_one_data = key_data;
				//full_data = 0;
				//EXTI->IMR |= (1<<11);
				}
			CHARACTER_MOVE_NEW(&character1, instruction);
			//CHARACTER_MOVE(&character2);
			UPDATE_BULLET_STATUS(&character1, &character2);
			WEAPON_PACKS_FALLING();
			HP_PACKS_FALLING();
		}
		if(TASKS[1] == 1)
		{
			TASKS[1] = 301;
			int flag = RANDOM_LOOT();
			if(flag == 0)
			{
				INIT_WEAPON_DROP();
			}
			else
			{
				INIT_HP_PACKS_DROP();
			}
		}
	}
}

void TIM2_IRQHandler(void)
{
	if(TIM2->SR & 1<<0)
	{
		CLEAR_TIMER();
		DRAW_TIMER(time);
		time--;
	}
	TIM2->SR &= ~(1<<0);
}

void TIM3_IRQHandler(void)
{
	if(TIM3->SR & 1<<0)
	{
		CHARACTER_CHANGE_BACK_WEAPON(&character1);
	}
	TIM3->SR &= ~(1<<0);
	NVIC->ICER[0] |= (1<<29);
}

void TIM4_IRQHandler(void)
{
	if(TIM3->SR & 1<<0)
	{
		CHARACTER_CHANGE_BACK_WEAPON(&character2);
	}
	TIM3->SR &= ~(1<<0);
	NVIC->ICER[0] |= (1<<30);
}
