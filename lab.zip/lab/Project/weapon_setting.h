#pragma once
#include "stm32f10x.h"
#include <stdlib.h>

typedef struct{
	int x,y;
	int status;
	char name[32];
	int damage;
	long int max_usage_time;
	int fire_rate;
}WEAPON;

typedef enum {
    WEAPON_PISTOL,
    WEAPON_VANDAL,
    WEAPON_PHANTOM,
    WEAPON_ODIN,
    WEAPON_COUNT
} WeaponType;

extern const WEAPON WEAPONS[WEAPON_COUNT];

typedef struct {
    WEAPON weapons[10];
    size_t size;
    //size_t capacity;
} WeaponList;

extern WeaponList weaponlist;

void weapon_list_init(WeaponList* list);

//void weapon_list_free(WeaponList* list);

void weapon_list_push(WeaponList* list, WEAPON entity);

void weapon_list_remove_at(WeaponList* list, size_t index);

const WEAPON* weapon_list_get(const WeaponList* list, size_t index);

size_t weapon_list_size(const WeaponList* list);

void INIT_WEAPON_DROP(void);

void WEAPON_PACKS_FALLING(void);
