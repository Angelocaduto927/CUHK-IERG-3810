#include <stm32f10x.h>
#include "IERG3810_Keypad.h"

extern u32 TASKS[10];

int READ_KEYPAD()
{
	ps2count = 0;
	ones = 0;
	full_data = 0;
	EXTI->IMR |= (1<<11);
	TASKS[4] = 3;
	while (ps2count < 11 && TASKS[4] > 1){}
	if(TASKS[4] == 1){return 0;}
	EXTI->IMR &= ~(1<<11);
	if (parity_check(full_data) == 1)
	{
		if (kp2_pressed)
		{
			return 1;
		}
		if (kp8_pressed)
		{
			return 2;
		}
		if (kp4_pressed)
		{
			return 3;
		}
		if (kp6_pressed)
		{
			return 4;
		}
		if (kpenter_pressed)
		{
			return 5;
		}
	}	
	else{}
	return 0;
}
