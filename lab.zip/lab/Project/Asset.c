#include "stm32f10x.h"
#include "LCD_SETUP.h"
#include "IERG3810_Clock.h"
#include "FONT.h"
#include "CFONT.h"
#include "IERG3810_Delay.h"


const u8 Character1[25][20]=  //red 1 black 2  dark gray 3  gray 4 light gray 5
{
	{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
	{1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0},
	{1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
	{0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0},
	{0,0,0,0,0,2,2,4,4,2,2,2,2,2,2,4,0,0,0,0},
	{0,0,0,0,2,4,4,2,2,4,4,4,4,4,2,2,4,0,0,0},
	{0,0,2,2,4,4,2,2,4,4,4,4,4,4,4,4,2,2,0,0},
	{0,0,2,4,4,2,2,4,4,4,4,2,2,4,4,4,4,2,4,0},
	{0,2,2,2,2,4,4,4,2,4,4,2,2,4,4,2,4,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,2,2,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,2,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,4,4,2,4,4,2,2,4,4,2,2,4,4,2,2,4,2,4},
	{0,2,2,4,2,2,4,4,2,4,4,2,2,4,4,2,4,2,2,0},
	{0,0,2,2,2,2,2,4,4,4,4,4,4,4,4,4,2,2,0,0},
	{0,0,3,3,3,4,2,2,2,2,2,2,2,2,2,2,3,3,3,0},
	{0,3,3,3,3,3,5,5,5,5,5,6,5,5,5,3,3,3,3,3},
	{0,3,3,3,3,3,2,2,2,5,5,5,5,2,2,2,3,3,3,3},
	{0,0,0,0,2,2,5,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,5,5,5,5,5,5,5,5,5,2,0,0,0,0},
	{0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,0,3,3,3,0,0,0,0,3,3,3,0,0,0,0,0},
	{0,0,0,0,0,0,3,3,0,0,0,0,0,3,3,0,0,0,0,0},
};
const u8 Character2[25][20]=  //red 1 black 2  dark gray 3  gray 4 light gray 5
{
	{0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,1,1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
	{1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0},
	{1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
	{0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0},
	{0,0,0,0,0,2,2,2,4,4,4,4,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,4,4,4,4,4,4,4,4,2,2,2,0,0,0},
	{0,0,2,2,2,4,4,4,4,4,4,4,4,4,4,2,2,2,0,0},
	{0,0,2,2,2,4,4,4,4,4,4,4,4,4,4,4,4,2,2,0},
	{0,2,2,2,4,4,4,4,4,4,4,4,4,4,4,4,4,4,2,2},
	{0,2,2,4,4,4,4,2,2,2,2,2,2,2,2,2,4,4,2,2},
	{0,2,2,4,4,4,2,2,2,2,2,2,2,2,2,2,2,4,2,2},
	{0,2,2,4,4,4,4,2,2,2,2,2,2,2,2,2,4,4,2,2},
	{0,2,2,4,4,4,4,4,4,4,4,2,2,2,4,4,4,4,2,2},
	{0,2,2,4,4,4,4,4,4,4,4,2,2,2,4,4,4,4,2,2},
	{0,0,2,2,2,2,4,4,4,4,4,2,2,2,4,4,4,2,2,0},
	{0,0,2,2,2,2,2,4,4,4,4,2,2,2,4,4,2,2,0,0},
	{0,0,3,3,3,4,2,2,2,2,2,2,2,2,2,2,3,3,3,0},
	{0,3,3,3,3,3,5,5,5,5,5,6,5,5,5,3,3,3,3,3},
	{0,3,3,3,3,3,2,2,2,5,5,5,5,2,2,2,3,3,3,3},
	{0,0,0,0,2,2,5,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,2,2,5,5,5,5,5,5,5,5,5,2,0,0,0,0},
	{0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0},
	{0,0,0,0,0,3,3,3,0,0,0,0,3,3,3,0,0,0,0,0},
	{0,0,0,0,0,0,3,3,0,0,0,0,0,3,3,0,0,0,0,0},
};


const u8 weapon0[6][20]=     //pistol
{
{0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,},
{0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};
const u8 weapon1[6][20]=     //vandal
{
{0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,},
{0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,},
{0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,},
{0,0,2,2,0,0,2,2,0,0,0,2,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,2,0,0,0,0,0,2,2,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,},
};

const u8 weapon2[6][20]=     //phantom
{

{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,},
{0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,},
{0,0,2,2,0,0,0,2,2,0,0,2,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,2,2,0,0,0,2,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
};

const u8 weapon3[6][20]=     //Odin
{

{0,5,5,0,5,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,},
{5,0,5,5,5,2,5,5,5,5,5,5,5,5,5,5,5,5,5,5,},
{5,5,5,5,5,2,5,5,5,5,5,5,5,5,5,5,5,5,0,0,},
{0,0,0,5,5,2,5,5,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,},
};
void drawDotForChar(u8 color, u16 x, u16 y)   
{
	if(color == 1) lcd_drawDot(x, y, c_RED);
	if(color == 2) lcd_drawDot(x, y, c_black);
	if(color == 3) lcd_drawDot(x, y, c_DARK_GRAY);
	if(color == 4) lcd_drawDot(x, y, c_GRAY);
	if(color == 5) lcd_drawDot(x, y, c_LIGHT_GRAY);
	if(color == 6) lcd_drawDot(x, y, c_GREEN);
}

void lcd_showChar(u16 x, u16 y, u8 ascii, u16 color)
{
	u8 i, b, temp1, temp2;
	u16 tempX, tempY;
	if (ascii<32 || ascii >127) return;
	ascii -= 32;
	tempX = x;
	for (i=0; i<16; i=i+2)
	{
		temp1 = asc2_1608[ascii][i];
		temp2 = asc2_1608[ascii][i+1];
		tempY = y;
		for (b=0;b<9;b++)
		{
			if(temp1%2 == 1) lcd_drawDot(tempY+8, tempX, color);
			if(temp2%2 == 1) lcd_drawDot(tempY, tempX, color);
			temp1 = temp1 >>1;
			temp2 = temp2 >>1;
			tempY++;
		}
		tempX--;
	}
}

void lcd_showChinChar(u16 x, u16 y, u8 ascii, u16 color)
{
	u8 i, b, temp1, temp2;
	u16 tempX, tempY;
	if (ascii>9) return;
	tempX= x;
	for (i=0; i<32; i=i+2)
	{
		temp1 = chi_1616[ascii][i];
		temp2 = chi_1616[ascii][i+1];
		tempY = y;
		for (b=0;b<8;b++)
		{
			if (temp1%2 == 1) lcd_drawDot(tempY+8, tempX, color);
			if (temp2%2 == 1) lcd_drawDot(tempY, tempX, color);
			temp1 = temp1 >> 1;
			temp2 = temp2 >> 1;
			tempY++;
		}
		tempX--;
	}
}







/////////////////////////////////////////Only use below function////////////////////////////////////////
void Draw_Character(u16 x, u16 y, u8 which, s8 d, u8 weapon) // d directtion can be 1 (right) or -1 (left)
{	
	u8 tempcolor,i,j;
	u16 coordx,coordy;
	if(which == 1)
	{
		for(i=0;i<25;i++)
		{
			for(j=0;j<20;j++)
			{
				tempcolor = Character1[i][j];
				coordy = y + 18 - i; 
				coordx = x - (11 - j)*d;// change direction
				drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	else
	{
		for(i=0;i<25;i++)
		{
			for(j=0;j<20;j++)
			{
				tempcolor = Character2[i][j];
				coordy = y + 18 - i; 
				coordx = x - (11 - j)*d;// change direction
				drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	//draw weapon/////////////////////////////////////////////
	if(weapon==0)
	{
	for(i=0;i<6;i++)
		{
			for(j=0;j<20;j++)
			{
				tempcolor = weapon0[i][j];
				coordy = y + 2 - i; 
				coordx = x - (11 - j)*d;// change direction
				drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	else if(weapon==1)
	{
		for(i=0;i<6;i++)
			{
				for(j=0;j<20;j++)
				{
					tempcolor = weapon1[i][j];
					coordy = y + 2 - i; 
					coordx = x - (11 - j)*d;// change direction
					drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	else if(weapon==2)
	{
		for(i=0;i<6;i++)
			{
				for(j=0;j<20;j++)
				{
					tempcolor = weapon2[i][j];
					coordy = y + 2 - i; 
					coordx = x - (11 - j)*d;// change direction
					drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
	else if(weapon==3)
	{
		for(i=0;i<6;i++)
			{
				for(j=0;j<20;j++)
				{
					tempcolor = weapon3[i][j];
					coordy = y + 2 - i; 
					coordx = x - (11 - j)*d;// change direction
					drawDotForChar(tempcolor, coordy, coordx);
			}
		}
	}
}
void Draw_ARENA(void)
{
	lcd_fillRectangle(c_black,0,10,0,320); //level 1
	
	lcd_fillRectangle(c_black,50,10,0,120); //level 2
	lcd_fillRectangle(c_black,50,10,200,120);
	
	lcd_fillRectangle(c_black,100,10,80,160); //level 3
	
}

void Draw_HPValue1(u8 HP_value1)
{
	lcd_fillRectangle(c_black,223,14,213,104);
	if(HP_value1 > 0)
	{
		lcd_fillRectangle(c_GREEN,225,10,315-HP_value1,HP_value1);
	}
}

void Draw_HPValue2(u8 HP_value2)
{
	lcd_fillRectangle(c_black,223,14,3,104);
	if(HP_value2 > 0)
	{	
		lcd_fillRectangle(c_GREEN,225,10,5,HP_value2);
	}
}


void Draw_Countdown(u8 min, u8 sec)
{
	u8 sec1,sec2;
	sec2 = sec%10;
	sec1 = sec/10; 
	lcd_showChar(176, 224, 0x30+min, c_black);
	lcd_showChar(168, 224, 0x3A, c_black);
	lcd_showChar(160, 224, 0x30+sec1, c_black);
	lcd_showChar(152, 224, 0x30+sec2, c_black);
}

void Draw_HealPack(u16 x, u16 y)
{
	lcd_fillRectangle(c_LIGHT_GRAY, x-7, 15, y-8, 16);
	//lcd_showChar(x-3, y+4, 0x48, c_YELLOW);
	lcd_showChar(y+3, x-7, 0x48, c_YELLOW);
}


void Draw_Bullet(u16 x, u16 y, u16 color)
{
	lcd_fillRectangle(color, x, 2, y, 10);
}

void Draw_front_page()
{
	lcd_showChar(120, 210, 109, c_YELLOW);
	lcd_showChar(128, 210, 101, c_YELLOW);
	lcd_showChar(136, 210, 104, c_YELLOW);
	lcd_showChar(144, 210, 121, c_YELLOW);
	lcd_showChar(152, 210, 97, c_YELLOW);
	lcd_showChar(160, 210, 77, c_YELLOW);
	lcd_showChar(168, 210, 32, c_YELLOW);
	lcd_showChar(176, 210, 110, c_YELLOW);
	lcd_showChar(184, 210, 117, c_YELLOW);
	lcd_showChar(192, 210, 71, c_YELLOW);
	
	lcd_showChar(112, 190, 115, c_YELLOW);
	lcd_showChar(120, 190, 114, c_YELLOW);
	lcd_showChar(128, 190, 111, c_YELLOW);
	lcd_showChar(136, 190, 116, c_YELLOW);
	lcd_showChar(144, 190, 117, c_YELLOW);
	lcd_showChar(152, 190, 98, c_YELLOW);
	lcd_showChar(160, 190, 105, c_YELLOW);
	lcd_showChar(168, 190, 114, c_YELLOW);
	lcd_showChar(176, 190, 116, c_YELLOW);
	lcd_showChar(184, 190, 110, c_YELLOW);
	lcd_showChar(192, 190, 111, c_YELLOW);
	lcd_showChar(200, 190, 67, c_YELLOW);
	
	lcd_showChar(96, 170, 56, c_YELLOW);
	lcd_showChar(104, 170, 57, c_YELLOW);
	lcd_showChar(112, 170, 48, c_YELLOW);
	lcd_showChar(120, 170, 53, c_YELLOW);
	lcd_showChar(128, 170, 49, c_YELLOW);
	lcd_showChar(136, 170, 50, c_YELLOW);
	lcd_showChar(144, 170, 53, c_YELLOW);
	lcd_showChar(152, 170, 53, c_YELLOW);
	lcd_showChar(160, 170, 49, c_YELLOW);
	lcd_showChar(168, 170, 49, c_YELLOW);
	lcd_showChinChar(184, 170, 5, c_YELLOW);
	lcd_showChinChar(200, 170, 4, c_YELLOW);
	lcd_showChinChar(216, 170, 3, c_YELLOW);
	
	
	lcd_showChar(96, 150, 51, c_YELLOW);
	lcd_showChar(104, 150, 49, c_YELLOW);
	lcd_showChar(112, 150, 49, c_YELLOW);
	lcd_showChar(120, 150, 53, c_YELLOW);
	lcd_showChar(128, 150, 49, c_YELLOW);
	lcd_showChar(136, 150, 50, c_YELLOW);
	lcd_showChar(144, 150, 53, c_YELLOW);
	lcd_showChar(152, 150, 53, c_YELLOW);
	lcd_showChar(160, 150, 49, c_YELLOW);
	lcd_showChar(168, 150, 49, c_YELLOW);
	lcd_showChinChar(184, 150, 2, c_YELLOW);
	lcd_showChinChar(200, 150, 1, c_YELLOW);
	lcd_showChinChar(216, 150, 0, c_YELLOW);
	
	lcd_fillRectangle(c_YELLOW, 90, 5, 90, 135);
	lcd_fillRectangle(c_YELLOW, 145, 5, 90, 135);
	lcd_fillRectangle(c_YELLOW, 90, 60, 90, 5);
	lcd_fillRectangle(c_YELLOW, 90, 60, 225, 5);
	
	lcd_showChar(120, 125, 101, c_YELLOW);
	lcd_showChar(128, 125, 109, c_YELLOW);
	lcd_showChar(136, 125, 97, c_YELLOW);
	lcd_showChar(144, 125, 71, c_YELLOW);
	lcd_showChar(152, 125, 32, c_YELLOW);
	lcd_showChar(160, 125, 116, c_YELLOW);
	lcd_showChar(168, 125, 114, c_YELLOW);
	lcd_showChar(176, 125, 97, c_YELLOW);
	lcd_showChar(184, 125, 116, c_YELLOW);
	lcd_showChar(192, 125, 83, c_YELLOW);
	
	lcd_showChar(120, 105, 50, c_YELLOW);
	lcd_showChar(128, 105, 121, c_YELLOW);
	lcd_showChar(136, 105, 101, c_YELLOW);
	lcd_showChar(144, 105, 107, c_YELLOW);
	lcd_showChar(152, 105, 32, c_YELLOW);
	lcd_showChar(160, 105, 115, c_YELLOW);
	lcd_showChar(168, 105, 115, c_YELLOW);
	lcd_showChar(176, 105, 101, c_YELLOW);
	lcd_showChar(184, 105, 114, c_YELLOW);
	lcd_showChar(192, 105, 80, c_YELLOW);
	
	lcd_fillRectangle(c_YELLOW, 20, 5, 90, 135);
	lcd_fillRectangle(c_YELLOW, 75, 5, 90, 135);
	lcd_fillRectangle(c_YELLOW, 20, 60, 90, 5);
	lcd_fillRectangle(c_YELLOW, 20, 60, 225, 5);
	
	lcd_showChar(120, 50, 101, c_YELLOW);
	lcd_showChar(128, 50, 103, c_YELLOW);
	lcd_showChar(136, 50, 97, c_YELLOW);
	lcd_showChar(144, 50, 80, c_YELLOW);
	lcd_showChar(152, 50, 32, c_YELLOW);
	lcd_showChar(160, 50, 32, c_YELLOW);
	lcd_showChar(168, 50, 111, c_YELLOW);
	lcd_showChar(176, 50, 102, c_YELLOW);
	lcd_showChar(184, 50, 110, c_YELLOW);
	lcd_showChar(192, 50, 73, c_YELLOW);
	
	lcd_showChar(116, 30, 112, c_YELLOW);
	lcd_showChar(124, 30, 117, c_YELLOW);
	lcd_showChar(132, 30, 121, c_YELLOW);
	lcd_showChar(140, 30, 101, c_YELLOW);
	lcd_showChar(148, 30, 107, c_YELLOW);
	lcd_showChar(156, 30, 32, c_YELLOW);
	lcd_showChar(164, 30, 115, c_YELLOW);
	lcd_showChar(172, 30, 115, c_YELLOW);
	lcd_showChar(180, 30, 101, c_YELLOW);
	lcd_showChar(188, 30, 114, c_YELLOW);
	lcd_showChar(196, 30, 80, c_YELLOW);
}

void Draw_info_page()
{
	
}

void Draw_player1_win()
{
	lcd_showChar(96, 180, 33, c_black);
	lcd_showChar(104, 180, 115, c_black);
	lcd_showChar(112, 180, 110, c_black);
	lcd_showChar(120, 180, 111, c_black);
	lcd_showChar(128, 180, 105, c_black);
	lcd_showChar(136, 180, 116, c_black);
	lcd_showChar(144, 180, 97, c_black);
	lcd_showChar(152, 180, 108, c_black);
	lcd_showChar(160, 180, 117, c_black);
	lcd_showChar(168, 180, 116, c_black);
	lcd_showChar(176, 180, 97, c_black);
	lcd_showChar(184, 180, 114, c_black);
	lcd_showChar(192, 180, 103, c_black);
	lcd_showChar(200, 180, 110, c_black);
	lcd_showChar(208, 180, 111, c_black);
	lcd_showChar(216, 180, 67, c_black);
	lcd_showChar(112, 160, 33, c_black);
	lcd_showChar(120, 160, 110, c_black);
	lcd_showChar(128, 160, 105, c_black);
	lcd_showChar(136, 160, 87, c_black);
	lcd_showChar(144, 160, 32, c_black);
	lcd_showChar(152, 160, 49, c_black);
	lcd_showChar(160, 160, 114, c_black);
	lcd_showChar(168, 160, 101, c_black);
	lcd_showChar(176, 160, 121, c_black);
	lcd_showChar(184, 160, 97, c_black);
	lcd_showChar(192, 160, 108, c_black);
	lcd_showChar(200, 160, 80, c_black);
}

void Draw_player2_win()
{
	lcd_showChar(96, 180, 33, c_black);
	lcd_showChar(104, 180, 115, c_black);
	lcd_showChar(112, 180, 110, c_black);
	lcd_showChar(120, 180, 111, c_black);
	lcd_showChar(128, 180, 105, c_black);
	lcd_showChar(136, 180, 116, c_black);
	lcd_showChar(144, 180, 97, c_black);
	lcd_showChar(152, 180, 108, c_black);
	lcd_showChar(160, 180, 117, c_black);
	lcd_showChar(168, 180, 116, c_black);
	lcd_showChar(176, 180, 97, c_black);
	lcd_showChar(184, 180, 114, c_black);
	lcd_showChar(192, 180, 103, c_black);
	lcd_showChar(200, 180, 110, c_black);
	lcd_showChar(208, 180, 111, c_black);
	lcd_showChar(216, 180, 67, c_black);
	lcd_showChar(112, 160, 33, c_black);
	lcd_showChar(120, 160, 110, c_black);
	lcd_showChar(128, 160, 105, c_black);
	lcd_showChar(136, 160, 87, c_black);
	lcd_showChar(144, 160, 32, c_black);
	lcd_showChar(152, 160, 50, c_black);
	lcd_showChar(160, 160, 114, c_black);
	lcd_showChar(168, 160, 101, c_black);
	lcd_showChar(176, 160, 121, c_black);
	lcd_showChar(184, 160, 97, c_black);
	lcd_showChar(192, 160, 108, c_black);
	lcd_showChar(200, 160, 80, c_black);
}

void Draw_overtime(void)
{
	lcd_showChar(124, 180, 33, c_black);
	lcd_showChar(132, 180, 101, c_black);
	lcd_showChar(140, 180, 109, c_black);
	lcd_showChar(148, 180, 105, c_black);
	lcd_showChar(156, 180, 116, c_black);
	lcd_showChar(164, 180, 114, c_black);
	lcd_showChar(172, 180, 101, c_black);
	lcd_showChar(180, 180, 118, c_black);
	lcd_showChar(188, 180, 79, c_black);
	delay(10000000);
	lcd_fillRectangle(c_white, 175, 20, 120, 80);
}


///remember to replace delay with systick
/*int main(void)
{
	delay(1000000);
	lcd_init();
	delay(1000000);
	lcd_fillRectangle(c_SADDLE_BROWN,0,240,0,320);
	Draw_ARENA();
	Draw_Character(11,16,1,1);
	Draw_Character(308,16,2,-1);
	Draw_HPValue(39,88);

  Draw_Countdown(3,12);
	while(1);

}*/


