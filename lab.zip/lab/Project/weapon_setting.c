#include <cstring>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <cstring>
#include "stm32f10x.h"
#include "weapon_setting.h"
#include "randomness.h"
#include "level_setting.h"
#include "character_setting.h"
#include "draw.h"

WeaponList weaponlist;

const WEAPON WEAPONS[WEAPON_COUNT] = {
    [WEAPON_PISTOL] = {
        .name = "Pistol",
        .damage = 1,
        .max_usage_time = 1000000000,
        .fire_rate = 40
    },
    [WEAPON_VANDAL] = {
        .name = "Vandal",
        .damage = 5,
        .max_usage_time = 100000,
        .fire_rate = 20
    },
    [WEAPON_PHANTOM] = {
        .name = "Phantom",
        .damage = 4,
        .max_usage_time = 100000,
        .fire_rate = 20
    },
    [WEAPON_ODIN] = {
        .name = "Odin",
        .damage = 2,
        .max_usage_time = 100000,
        .fire_rate = 10
    }
};

void weapon_list_init(WeaponList* list) {
    list->size = 0;
}

/*
void weapon_list_free(WeaponList* list) {
    free(list->weapon);
    list->weapon = NULL;
    list->size = 0;
    list->capacity = 0;
}
*/

/*
static void weapon_list_grow(WeaponList* list) {
    list->capacity *= 2;
    WEAPON* new_weapon = realloc(list->weapon, list->capacity * sizeof(WEAPON));
    if (!new_weapon) {
        fprintf(stderr, "Realloc failed!\n");
        exit(1);
    }
    list->weapon = new_weapon;
}
*/

void weapon_list_push(WeaponList* list, WEAPON entity) {
		if (list->size == 10) {
        return ; 
    }
    list->weapons[list->size] = entity;
    list->size++;
}

void weapon_list_remove_at(WeaponList* list, size_t index) {
    if (index >= list->size) return;
    memmove(&list->weapons[index], &list->weapons[index + 1],
            (list->size - index - 1) * sizeof(WEAPON));
    list->size--;
}

const WEAPON* weapon_list_get(const WeaponList* list, size_t index) {
    if (index >= list->size) return NULL;
    return &list->weapons[index];
}

size_t weapon_list_size(const WeaponList* list) {
    return list->size;
}

void INIT_WEAPON_DROP()
{
	u8 random_weapon_index;
	random_weapon_index = rand() % 4;
	WEAPON weapon = WEAPONS[random_weapon_index];
	weapon.status = 1;
	weapon.x = 197;
	weapon.y = RANDOM_RANGE(20,300);
	weapon_list_push(&weaponlist, weapon);
}

void WEAPON_PACKS_FALLING()
{
	for(size_t i=0; i<weaponlist.size; i++)
	{
		if(weaponlist.weapons[i].status == 1)
		{
			CLEAR_WEAPON(weaponlist.weapons[i]);
			weaponlist.weapons[i].x-=10;
			for(int j = 0; j < LEVEL_GROUND_COUNT; j++) {
				if ((weaponlist.weapons[i].x == level_ground[j].height + 7) && (weaponlist.weapons[i].y >= level_ground[j].start) && (weaponlist.weapons[i].y <= level_ground[j].end))
				{
					weaponlist.weapons[i].status = 0;	
				}
			}
			DRAW_WEAPON_LOOT(weaponlist.weapons[i]);
		}
	}	
}


